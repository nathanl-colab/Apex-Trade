---
name: Python web artifact on Replit
description: How to host a Python/Streamlit app as an artifact when no Python template exists
---

There is no Python/Streamlit artifact template in this monorepo. To host a Python web app:

1. Create a `web` artifact (the `react-vite` kind) via `createArtifact`, which assigns a slug, `$PORT`, and `/` route.
2. Replace the React scaffold contents with the Python app under `artifacts/<slug>/`.
3. Repoint the `artifact.toml` dev/production run commands to the Python launcher via `verifyAndReplaceArtifactToml`.

**Why:** `kind` and `integratedSkills` cannot be changed after creation, and direct edits to `artifact.toml` are blocked — only `verifyAndReplaceArtifactToml` works, and it cannot create artifacts.

**How to apply:**
- The artifact run command executes with the artifact dir as CWD. Use CWD-independent `pnpm --filter @workspace/<slug> run <script>` scripts, never `cd artifacts/...`.
- Bind the server to `0.0.0.0` and the assigned `$PORT` (fall back to 5000). For Streamlit, also set headless + address in `.streamlit/config.toml`.
- Commands touching `.git` (git mv, rm .git/index.lock) are blocked for the main agent; use plain `mv`.
