---
name: Apex Trade bundle quirks
description: Non-obvious behaviors of the user-provided WSB/yfinance bundle
---

The Apex Trade app is built from a user-provided Python bundle (Streamlit + yfinance + an OpenAI WSB sentiment classifier).

- **yfinance cannot resolve fictional / pre-IPO tickers** (e.g. SPCX, SWBI from the bundle snapshot). Live calls return no price. `ticker_prices.csv` is the offline snapshot used as a fallback inside `get_stock_info`, so the app stays useful for those names and during network outages.
  - **How to apply:** preloaded examples must use real, resolvable tickers; rely on the snapshot only as a fallback. A recommendation with no live price and no snapshot match is flagged (`data_ok=False`, action `NO DATA`) and suppressed from dashboard buckets.
- **The classifier prompt asks the model to output `:positive` / `:neutral` / `:negative`** (leading colon, lowercase). Any output parser must strip the leading colon and lowercase before matching, or every AI classification silently falls back to Neutral.
  - **Why:** the original bundle parser capitalized and matched `Positive/Negative/Neutral`, which never matched the prompt's own format.
- The classifier hardcodes a non-existent model; the app overrides it to `gpt-4o-mini` at runtime. `OPENAI_API_KEY` is optional — without it the Sentiment Lab degrades to a rules-based classifier.
